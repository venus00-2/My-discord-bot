# Overview

This is a Discord bot built with Python using the discord.py library. The bot provides a friendly, casual companion experience with features like personalized greetings, advice, and jokes. It responds to mentions of its name and supports command-based interactions with a `!` prefix.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Framework**: discord.py with commands extension
- **Command Prefix**: `!` for all bot commands
- **Intents**: Default intents with message content enabled for reading user messages

## Event Handling
- **on_ready**: Logs when the bot comes online
- **on_message**: Handles passive responses when the bot's name is mentioned in chat, then processes commands

## Command Structure
- Commands are defined using the `@bot.command()` decorator
- Current commands: `!advice`, `!joke`
- Responses are randomly selected from predefined lists for variety

## Authentication
- Bot token is expected to be provided via environment variables (not hardcoded in source)
- The bot token should be stored in a `DISCORD_TOKEN` environment variable

## Design Patterns
- **Response Randomization**: All bot responses use random selection from curated lists to feel more natural
- **Self-Message Filtering**: Bot ignores its own messages to prevent loops

# External Dependencies

## Python Packages
- **discord.py**: Core Discord API wrapper for bot functionality
- **random**: Standard library for randomizing responses
- **os**: Standard library for environment variable access

## External Services
- **Discord API**: Bot connects to Discord's gateway for real-time message handling
- Requires a Discord Bot Token from the Discord Developer Portal