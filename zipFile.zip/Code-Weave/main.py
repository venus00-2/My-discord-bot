import discord
from discord.ext import commands
import random
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)

venus_mention_count = {}

@bot.event
async def on_ready():
    print(f'{bot.user} is now online!')

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    content = message.content.lower()
    user_id = message.author.id
    
    if 'venus' in content:
        if user_id not in venus_mention_count:
            venus_mention_count[user_id] = 0
        venus_mention_count[user_id] += 1
        
        if venus_mention_count[user_id] >= 3:
            angry_responses = [
                f"WHAT DO YOU WANT MOTHERFUCKER?! 😤",
                f"That's why I fucked your mom, {message.author.name}. 🖕",
                "Just get the frick offline you cunt! 👿",
                f"OKAY {message.author.name}, I HEARD YOU THE FIRST TIME! 🔥",
                "I swear to god if you say my name ONE more time... 😠",
                "You're really pissing me off right now! 💢"
            ]
            await message.channel.send(random.choice(angry_responses))
            venus_mention_count[user_id] = 0
        else:
            greetings = [
                f'Hi love, {message.author.name} 💖',
                "Hey sugar, how's your day going?",
                'Hello there! Need advice, jokes, or just company? 😏',
                "I'm here, ready to chat! 💫"
            ]
            await message.channel.send(random.choice(greetings))
    else:
        venus_mention_count[user_id] = 0

    await bot.process_commands(message)

@bot.command()
async def advice(ctx):
    advices = [
        'Trust yourself, you got this!',
        'Small steps every day lead to big changes.',
        'Even clouds have silver linings, sugar.'
    ]
    await ctx.send(random.choice(advices))

@bot.command()
async def joke(ctx):
    jokes = [
        'Why did the scarecrow win an award? Because he was outstanding in his field! 🌾',
        "I would tell a joke about chemistry, but I know I wouldn't get a reaction. ⚗️",
        "Why don't eggs tell jokes? They'd crack each other up! 🥚"
    ]
    await ctx.send(random.choice(jokes))

@bot.command()
async def question(ctx, *, q):
    answers = [
        'Hmm... I think yes.',
        'Maybe... try again later.',
        'Absolutely!',
        "I wouldn't count on it.",
        'Definitely, sugar!'
    ]
    await ctx.send(random.choice(answers))

@bot.command()
async def help(ctx):
    help_text = """**Here's what I can do for you! 💖**

**Commands:**
`!advice` - Get some uplifting advice
`!joke` - Hear a funny joke
`!question <your question>` - Ask me anything and I'll give you an answer
`!help` - Show this help message

**Or just mention my name in chat and I'll say hi!** 😊"""
    await ctx.send(help_text)

bot.run(os.environ['DISCORD_TOKEN'])
